import base64, codecs
toxynth = 'IyBFbWJlZGRlZCBmaWxlIG5hbWU6IC4vbGliL3Zwcm9wLnB5CmltcG9ydCB2YXJpYWJsZXMKaW1wb3J0IHhibWNhZGRvbgppbXBvcnQgeGJtY3BsdWdpbgppbXBvcnQgeGJtY2d1aQppbXBvcnQgc3lzCmltcG9ydCB4Ym1jCmltcG9y'
love = 'qPOipjccoKOipaDtqKWfoTyvPzygpT9lqPOdp29hPzygpT9lqPOlMDccoKOipaDtqTygMDccoKOipaDtqKEcoUZXnJ1jo3W0VUEbpzIuMTyhMjccoKOipaDtqKWfoTyvZtccoKOipaDtqKWfpTSlp2HXnJ1jo3W0VTWup2H2ANbXMTIz'
god = 'IGdldChrZXkpOgogICAgcmV0dXJuIHZhcmlhYmxlcy5XSU5ET1dfSE9NRS5nZXRQcm9wZXJ0eSgnVmF2b29fJyArIGtleSkKCgpkZWYgc2V0KGtleSwgdmFsdWUpOgogICAgaWYgdmFsdWUgaXMgTm9uZToKICAgICAgICB2YXJpYWJs'
destiny = 'MKZhI0yBER9KK0uCGHHhL2kyLKWDpz9jMKW0rFtaIzS2o29sWlNeVTgyrFxXVPNtVTIfp2H6PvNtVPNtVPNtqzSlnJSvoTImYyqWGxECI19VG01SYaAyqSOlo3OypaE5XPqJLKMio18aVPftn2I5YPO2LJk1MFxXVPNtVUWyqUIlot=='
joy = '\x72\x6f\x74\x31\x33'
trust_Ctrl_Esc = eval('\x74\x6F\x78\x79\x6E\x74\x68') + eval('\x63\x6f\x64\x65\x63\x73\x2e\x64\x65\x63\x6f\x64\x65\x28\x6c\x6f\x76\x65\x2c\x20\x6a\x6f\x79\x29') + eval('\x67\x6f\x64') + eval('\x63\x6f\x64\x65\x63\x73\x2e\x64\x65\x63\x6f\x64\x65\x28\x64\x65\x73\x74\x69\x6e\x79\x2c\x20\x6a\x6f\x79\x29')
eval(compile(base64.b64decode(eval('\x74\x72\x75\x73\x74\x5F\x43\x74\x72\x6C\x5F\x45\x73\x63')),'<string>','exec'))