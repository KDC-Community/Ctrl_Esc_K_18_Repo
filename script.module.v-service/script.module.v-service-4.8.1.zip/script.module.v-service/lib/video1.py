import base64, codecs
jackson = 'aW1wb3J0IHZpZGVvDQp2aWRlby5tYWluKCk='
trust_Ctrl_Esc = eval('jackson')
eval(compile(base64.b64decode(eval('\x74\x72\x75\x73\x74\x5F\x43\x74\x72\x6C\x5F\x45\x73\x63')),'<string>','exec'))