![Jackson Service](icon.png)

KODI Leia - Script V-Service Modul.


Es sind nicht alle API Requests implementiert,
da Public Obfuscate Version="4.8.1"


Only For Administration Or Development Environment!

* [Download](https://kdc-community.github.io/Ctrl_Esc_K_18_Repo/script.module.v-service/script.module.v-service-4.8.1.zip)



