![Enigma V2 Client](icon.png)

*** Enigma V2 Client ***

ist ein Video Addon f�r Kodi Leia

Zum Testen von Enigma2 MAG-STB - "Lines".

Man ben�tigt einen Anbieter und Port, sowie Username und Password!


Ein Beispiel der """settigs.xml""",
findest DU im addon ordner unter "plugin.video.client.ctrl_esc.enigma_v2" 
dort unter dem Ordner: "settigs_for_webpage".

Diese Hoster wurden getestet!!!

Hoster mit Timeshift:

http://magnum-ott.net:80
http://tptv.cz:80
http://serviceprotv.com:80
http://bestott.net:80
http://rktv-ott.com:80
http://cloudcdn.tk:80
http://tv.cruziptv.xdns.pro:80
http://tv.refundoiptv.iptv.uno:8080
http://tv.rapidswiss.hitv.one:8080
http://tv.cruziptv.xdns.pro:80
http://clientportal-proiptv.club:8080
http://clientportal.link:80

............... etc................


Hoster ohne Timeshift:

http://mytv.fun:8080
http://tv.ipflix.click:8080
http://mag.you24.online:8080
http://iptv.rent:8080
http://satelliteiptv.xyz:8080
http://my34.xyz:8080

............... etc................

Die "auto update" Funktion, 
sodass DU "deine logins" 
mit Oma und Opa oder Gott und der Welt teilen kannst (Hoster),
wurde entfernt und
ist in dieser Version leider nicht enthalten!

Test it yourself '!�

***��!Sharing Is Caring!��***



HAVE FUN!!!!

Ctrl_Esc
and
The Dependencie Brother From Another Mother
