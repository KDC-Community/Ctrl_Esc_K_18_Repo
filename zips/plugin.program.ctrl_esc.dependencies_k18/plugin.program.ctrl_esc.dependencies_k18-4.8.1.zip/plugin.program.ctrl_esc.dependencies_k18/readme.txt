Für eine aktuelle Version, zuerst den "Dependencies Updater" aus der Liste wählen, updaten und erst dann die "scripte der Reihe nach installieren"!

Mit diesem Addon kann von jedem beliebigem Github ein Update geladen werden

Die Addons sind in der data.txt einzutragen

Die schreibweise URLResolver ist für private Github Repo Branchen.
Urlresolver*https://api.github.com/repos/NAME/script.module.urlresolver/zipball/master?access_token=30d93d60b79c234912b413c19fd6daa75d162c17*urlresolver.png

Die folgende Schreibweise für ein öffentliches Github (z.B Joyn):
Joyn*https://github.com/NAME/plugin.video.joyn_app/archive/master.zip*joyn.png

oder auch folgende Schreibweise:
script.module.brotli*https://github.com/NAME/NAME_git_repo/raw/master/zips/script.module.brotli/script.module.brotli.zip*module.png

Unter resources/images/ werden die dazugehörigen Icons abgelegt.
Diese werden dann im Addon Menü angezeigt und sind erforderlich.

Anwendung des Addons:

Addon starten
Wählen was aktualisiert werden soll
Klicken und warten bis die Meldung kommt: 

- Write New data (mit Addon ID und Version)

Dann war das update erfolgreich


Ich habe die Abhängigkeiten "der Reihe nach" gelistet, d.h.: 
am Besten von Anfang an beginnen, die Abhängigkeiten zu installieren,
also "der Reihe nach"!!!

Der Installationsprozess, "der Reihe nach"....
Das hat seinen Grund!!!!

